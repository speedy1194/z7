/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Program;
public class SampleData
{
protected boolean grid[][];
protected char letter;
/* Konstruktor */
public SampleData(char letter, int width, int height)
  {
grid = new boolean[width][height];
this.letter = letter;
  }
/* Pixel przyk�adu */
public void setData(int x, int y, boolean v)
  {
grid[x][y] = v;
  }
public boolean getData(int x, int y)
{
return grid[x][y];
  }
/* Czyszczeniespr�bkowanegoobrazu */
public void clear()
  {
for (int x = 0; x<grid.length; x++)
for (int y = 0; y<grid[0].length; y++)
grid[x][y] = false;
  }
/* Wysoko��obrazu */
public int getHeight()
  {
return grid[0].length;
  }
/* Szeroko�� */
public int getWidth()
  {
return grid.length;
}
/* Znakreprezentuj�cyobraz */
public char getLetter()
{
return letter;
  }
public void setLetter(char letter)
{
this.letter = letter;
  }
/* Por�wnaniepr�bki */
public int compareTo(Object o)
  {
    SampleData obj = (SampleData) o;
if (this.getLetter() == obj.getLetter())
return 0;
else if (this.getLetter() >obj.getLetter())
return 1;
else
return -1;
  }
public boolean equals(Object o)
  {
return (compareTo(o) == 0);
  }
/* Konwersja w string */
public String toString()
  {
return"" + letter;
  }
/* Kopiapr�bki */
public Object clone()
  {
    SampleData obj = new SampleData(letter, getWidth(), getHeight());
for (int y = 0; y< getHeight(); y++)
for (int x = 0; x< getWidth(); x++)
obj.setData(x, y, getData(x, y));
return obj;
}
}

