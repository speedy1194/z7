package Program;


import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Vector;

import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class Program extends JApplet {

	
	private static final long serialVersionUID = 1L;

	public Program() {
	}
	
/* Szeroko��siatki */
	
static final int DOWNSAMPLE_WIDTH = 5;

/* Wysoko��siatki */

static final int DOWNSAMPLE_HEIGHT = 7;

Vector sampleList = new Vector();;

/* Komponent do wprowadzaniaznaku */

  Entry entry;

/* Wy�wietlenieprzyk�adu */

  Sample sample;

/* Sie�neuronowa */

  KohonenNetwork net;

/* Binarnyzapisliter */

public static final String HANDWRITING[] = {
	"A:00100001000111001010110111111110001",
	"a:01110100101001010010100101001001111",
	"B:11111100111000111111100011001111111",
	"b:10000100001000011111100011000111111",
	"C:11111100011000010000100001000111111",
	"D:11110100111000110001100011001111110",
	"d:00001000010000111111100011000111111",
	"E:11111100001000011111100001000011111",
	"e:01110110111000111111100001000111111",
	"F:11111100001000011111100001000010000",
	"f:00111001000010000100111110010000100",
	"G:11111100011000010111100011000111111",
	"g:11100101011111100110111001010011100",
	"H:10001100011000111111100011000110001",
	"h:10000100001000011111100011000110001",
	"I:00100001000010000100001000010000100",
	"i:00100000000110011100101000010000111",
	"J:11100001000010100111111001010011100",
	"j:00100000000010100110011001010011100",
	"K:10001101111110011000111001011010011",
	"k:10000100001000010011111101110010111",
	"L:10000100001000010000100001000011111",
	"l:10000100001000010000100001100101111",
	"M:10001110111010110001100011000110001",
	"m:11110111111010110101101011010110101",
	"N:10001110011110110101101111001110001",
	"n:11110110101101010010100101001010011",
	"O:11111100011000110001100011000111111",
	"Q:11111100011000110001101011001111111",
	"q:11100101001110000101001110011000100",
	"P:11111100011000111111100001000010000",
	"R:11111100011000111111111001011010011",
	"r:11011111111111111100111000110001100",
	"S:11111100011000011111000011000111111",
	"s:00100011100101111001100010100101111",
	"T:11111001000010000100001000010000100",
	"t:00100001000010011111001000010000111",
	"U:10001100011000110001100011000111111",
	"u:10010100101011010110101101011011111",
	"V:10001100011000111011110110111001110",
	"W:10001100011000110101111111101110001",
	"w:10001101011010110101101011111111110",
	"X:10001110110111000100011101101110001",
	"Y:10001110110111000100001000010000100",
	"y:10100101001110100111111001010011100",
	"Z:11111000010001000100010001000011111",
      };

/* Layout programu */

public void init()
  {
	
	setSize(600,200);
	
	
    preload();
    updateList();

    getContentPane().setLayout(new GridLayout(1, 2));

    JPanel topPanel = new JPanel();
    JPanel bottomPanel = new JPanel();

    JPanel topButtonPanel = new JPanel();
    JPanel bottomButtonPanel = new JPanel();
topButtonPanel.setLayout(new GridLayout(3, 1));
topButtonPanel.add(recognize = new JButton("Rozpoznaj"));
topButtonPanel.add(clear = new JButton("Wyczy�� obraz"));
    JPanel addPanel = new JPanel();
addPanel.setLayout(new GridLayout(1, 2));
addPanel.add(add = new JButton("Dodaj:"));
addPanel.add(letterToAdd);
topButtonPanel.add(addPanel);
letterToAdd.setText("1");

bottomButtonPanel.setLayout(new GridLayout(1, 2));
bottomButtonPanel.add(del = new JButton("Usu�"));
bottomButtonPanel.add(delAll = new JButton("Wyczy��"));
bottomButtonPanel.add(train = new JButton("Ucz sie�"));

entry = new Entry();
topPanel.setLayout(new BorderLayout());
topPanel.add(message = new JLabel("Narysuj liter� i kliknij 'Rozpoznaj'"),
        BorderLayout.NORTH);
message.setHorizontalAlignment(SwingConstants.CENTER);
topPanel.add(entry, BorderLayout.CENTER);
topPanel.add(topButtonPanel, BorderLayout.EAST);

bottomPanel.setLayout(new BorderLayout());
    JLabel label = new JLabel("Baza nauczonych liter:");
label.setHorizontalAlignment(SwingConstants.LEFT);
bottomPanel.add(label, BorderLayout.NORTH);
    JPanel bottomContent = new JPanel();
bottomContent.setLayout(new GridLayout(1, 2));
bottomPanel.add(bottomContent, BorderLayout.CENTER);
bottomPanel.add(bottomButtonPanel, BorderLayout.SOUTH);

    JPanel lettersPanel = new JPanel();
/*/ scrollPane1.add(letters); /*/
lettersPanel.setLayout(new BorderLayout());
lettersPanel.add(letters, BorderLayout.CENTER);

    JPanel downSamplePanel = new JPanel();
downSamplePanel.setLayout(new BorderLayout());
sample = new Sample(DOWNSAMPLE_WIDTH, DOWNSAMPLE_HEIGHT);
entry.setSample(sample);
downSamplePanel.add(sample, BorderLayout.CENTER);

bottomContent.add(lettersPanel);
bottomContent.add(downSamplePanel);

    getContentPane().add(topPanel);
    getContentPane().add(bottomPanel);

    Font dialogFont = new Font("Arial", Font.BOLD, 10);
clear.setFont(dialogFont);
add.setFont(dialogFont);
del.setFont(dialogFont);
delAll.setFont(dialogFont);
recognize.setFont(dialogFont);
train.setFont(dialogFont);

    SymAction lSymAction = new SymAction();
clear.addActionListener(lSymAction);
add.addActionListener(lSymAction);
del.addActionListener(lSymAction);
delAll.addActionListener(lSymAction);
    SymListSelection lSymListSelection = new SymListSelection();
letters.addItemListener(lSymListSelection);

train.addActionListener(lSymAction);
recognize.addActionListener(lSymAction);

message.setForeground(new Color(100, 149, 237));

entry.requestFocus();

  }

  JButton add = new JButton();

  JButton clear = new JButton();

  JButton recognize = new JButton();

  ScrollPane scrollPane1 = new ScrollPane();

  java.awt.List letters = new java.awt.List();

  JButton del = new JButton();

  JButton delAll = new JButton();

  JButton train = new JButton();

  JLabel message = new JLabel();

  JTextField letterToAdd = new JTextField("", 1);

class SymAction implements java.awt.event.ActionListener
  {
public void actionPerformed(java.awt.event.ActionEvent event)
    {
      Object object = event.getSource();
if (object == clear)
        clear_actionPerformed(event);
else if (object == add)
        add_actionPerformed(event);
else if (object == del)
        del_actionPerformed(event);
else if (object == delAll)
        deleteAll_actionPerformed(event);
else if (object == train)
        train_actionPerformed(event);
else if (object == recognize)
        recognize_actionPerformed(event);
    }
  }

/* Czyszczenieobrazu */

void clear_actionPerformed(java.awt.event.ActionEvent event)
  {
entry.clear();
sample.getData().clear();
sample.repaint();
  }

void deleteAll_actionPerformed(java.awt.event.ActionEvent event)
  {
sampleList.removeAllElements();
net = null;
    updateList();
entry.clear();
sample.getData().clear();
sample.repaint();
  }

/* Dodawanieznaku do listy */

void add_actionPerformed(java.awt.event.ActionEvent event)
  {
int i;

    String letter = letterToAdd.getText().trim();

if (letter.length() > 1)
    {
      JOptionPane.showMessageDialog(null,"Wpisz tylko jeden znak.");
return;
    }

if (letter.length() < 1)
    {
      JOptionPane.showMessageDialog(null,"Wpisz liter�, kt�r� chcesz zdefiniowa�.");
return;
    }

entry.downSample();
    SampleData sampleData = (SampleData) sample.getData().clone();
sampleData.setLetter(letter.charAt(0));

for (i = 0; i<sampleList.size(); i++)
    {
      SampleData str = (SampleData) sampleList.elementAt(i);
if (str.equals(sampleData))
{
	JOptionPane.showMessageDialog(null,"Litera jest ju� zdefiniowana!");
return;
      }

if (str.compareTo(sampleData) > 0)
      {
sampleList.insertElementAt(sampleData, i);
        updateList();
return;
      }
    }
sampleList.insertElementAt(sampleData, sampleList.size());
    updateList();
letters.select(i);
entry.clear();
sample.repaint();

  }

/* Usuwanie z listy */

void del_actionPerformed(java.awt.event.ActionEvent event)
  {
int i = letters.getSelectedIndex();

if (i == -1)
    {
	JOptionPane.showMessageDialog(null,"Wybierz liter�, kt�r� chcesz usun�� z bazy.");

return;
    }

sampleList.removeElementAt(i);
    updateList();
  }

class SymListSelection implements ItemListener
  {

public void itemStateChanged(ItemEvent event)
    {
      Object object = event.getSource();
if (object == letters)
        letters_valueChanged(event);

    }
  }

/* Wyb�r z listy */

void letters_valueChanged(ItemEvent event)
  {
if (letters.getSelectedIndex() == -1)
return;
    SampleData selected = (SampleData) sampleList.elementAt(letters
        .getSelectedIndex());
sample.setData((SampleData) selected.clone());
sample.repaint();
entry.clear();
  }

/* Uczeniesieci */

void train_actionPerformed(java.awt.event.ActionEvent event)
  {

try
    {
int inputNeuron = Program.DOWNSAMPLE_HEIGHT
          * Program.DOWNSAMPLE_WIDTH;
int outputNeuron = sampleList.size();

      TrainingSet set = new TrainingSet(inputNeuron, outputNeuron);
set.setTrainingSetCount(sampleList.size());

for (int t = 0; t<sampleList.size(); t++)
      {
int idx = 0;
        SampleData ds = (SampleData) sampleList.elementAt(t);
for (int y = 0; y<ds.getHeight(); y++)
        {
for (int x = 0; x<ds.getWidth(); x++)
          {
set.setInput(t, idx++, ds.getData(x, y) ? .5 : -.5);
          }
        }
      }

net = new KohonenNetwork(inputNeuron, outputNeuron, this);
net.setTrainingSet(set);
net.learn();
this.clear_actionPerformed(null);
      JOptionPane.showMessageDialog(null,"Sie� neuronowa zosta�a nauczona. \nProgram jest gotowy do pracy.");
    } catch (Exception e)
    {
message.setText("Exception:" + e.getMessage());
    }
  }

/* Rozpoznawanieznaku */

void recognize_actionPerformed(java.awt.event.ActionEvent event)
  {
if (net == null)
    {
      JOptionPane.showMessageDialog(null, "Najpierw naucz sie� neuronow�!");
return;
    }
entry.downSample();

double input[] = new double[5 * 7];
int idx = 0;
    SampleData ds = sample.getData();
for (int y = 0; y<ds.getHeight(); y++)
    {
for (int x = 0; x<ds.getWidth(); x++)
      {
input[idx++] = ds.getData(x, y) ? .5 : -.5;
      }
    }

double normfac[] = new double[1];
double synth[] = new double[1];

int best = net.winner(input, normfac, synth);
char map[] = mapNeurons();
    JOptionPane.showMessageDialog(null, "Litera rozpoznana jako: " + " " + map[best]);

clear_actionPerformed(null);
}

/* Przyporz�dkowanieneuron�w do znak�w */

char[] mapNeurons()
  {

char map[] = new char[sampleList.size()];
double normfac[] = new double[1];
double synth[] = new double[1];

for (int i = 0; i<map.length; i++)
map[i] = '?';
for (int i = 0; i<sampleList.size(); i++)
    {
double input[] = new double[5 * 7];
int idx = 0;
      SampleData ds = (SampleData) sampleList.elementAt(i);
for (int y = 0; y<ds.getHeight(); y++)
      {
for (int x = 0; x<ds.getWidth(); x++)
        {
input[idx++] = ds.getData(x, y) ? .5 : -.5;
}
      }

int best = net.winner(input, normfac, synth);
map[best] = ds.getLetter();
    }
return map;
  }

public void updateList()
  {
letters.removeAll();
for (int i = 0; i<sampleList.size(); i++)
    {
      SampleData sample = (SampleData) sampleList.elementAt(i);
letters.add("" + sample.letter);
    }
  }

public void preload()
  {
int index = 0;
for (int i = 0; i< Program.HANDWRITING.length; i++)
    {
      String line = HANDWRITING[i].trim();
      SampleData ds = new SampleData(line.charAt(0),
		  Program.DOWNSAMPLE_WIDTH, Program.DOWNSAMPLE_HEIGHT);
sampleList.insertElementAt(ds, index++);
int idx = 2;
for (int y = 0; y<ds.getHeight(); y++)
      {
for (int x = 0; x<ds.getWidth(); x++)
        {
ds.setData(x, y, line.charAt(idx++) == '1');
          }
        }
      }
    train_actionPerformed(null);
  }  
}
